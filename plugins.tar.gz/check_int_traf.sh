#!/bin/sh

### check_snmp_traffic
# Check trafic usage of an interface using snmp
#
# Version 0.2, Copyright (c) 2010 by Luc Duchosal <luc.duchosal@arcantel.ch>
#   Quick hack of Michael Boehm's check_snmp_cisco_traffic nagios plugin.
#   removed temporary file and added sleep between two checks.
#   Added bc expression for flexibility.
#
# Version 0.1, Copyright (c) 2008 by Michael Boehm <dudleyperkins_AT_gmail.com>
#
###

### License Information:
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# you should have received a copy of the GNU General Public License
# along with this program (or with Nagios);  if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA
###

#----if-help-is-needed------------------#

if [ "$1" = "help" -o ! "$#" -gt "4" ]; then
   echo -e "\nCheck traffic usage of an interface\n";
   echo -e "Version 0.2, Copyright (c) 2010 by Luc Duchosal <luc.duchosal@arcantel.ch>\nLast Modified: 2010-01-18\n";
   echo -e "--------------------------------------------------";
   echo -e "Usage: ./check_snmp_traffic <host> <snmp-community> <if-number> <warn> <crit>";
   echo -e "--------------------------------------------------\n";
   echo -e "<host>             Hostname or IP Address";
   echo -e "<snmp-community>   the snmp community string";
   echo -e "<if-number>        Interface number, use snmpwalk to find yours:";
   echo -e "";
   echo -e "      snmpwalk -v2c -c community host 1.3.6.1.2.1.31.1.1.1.1";
   echo -e "      IF-MIB::ifName.1 = STRING: Fa0";
   echo -e "               This -^- is the interface-number";
   echo -e "";
   echo -e "<warn>             warning if bc expression return 1";
   echo -e "<crit>             critical if bc expression return 1";
   echo -e ""
   echo -e "Exxamples : "
   echo -e "# ./check_snmp_traffic localhost private 1 \" > 1 \" \" > 2 \"";
   echo -e "WARNING if iface # 1 trafic > 1 Mbit/s, CRITICAL if trafic > 2 Mbits/";
   echo -e ""
   echo -e "# ./check_snmp_traffic localhost private 10 \" < 11 \" \" < 5 \"";
   echo -e "WARNING if iface # 10 has trafic < 11 Mbit/s, CRITICAL if trafic < 5 Mbits/";
   echo -e ""

   exit 0;

fi

#----variables-set-at-runtime-----------#

sleep=5
host=$1
snmpstring=$2
interface=$3
warn=$4
crit=$5

snmp_ifin="1.3.6.1.2.1.31.1.1.1.6"
snmp_ifout="1.3.6.1.2.1.31.1.1.1.10"

# last value
traflastIn=`snmpget -v2c -c $snmpstring $host $snmp_ifin.$interface |awk {'print $4'}`
traflastOut=`snmpget -v2c -c $snmpstring $host $snmp_ifout.$interface  |awk {'print $4'}`

sleep $sleep

# current value
trafbyteIn=`snmpget -v2c -c $snmpstring $host $snmp_ifin.$interface |awk {'print $4'}`
trafbyteOut=`snmpget -v2c -c $snmpstring $host $snmp_ifout.$interface  |awk {'print $4'}`

# echo "traflastIn: $traflastIn"
# echo "trafbyteIn: $trafbyteIn"
#
# echo "traflastOut: $traflastOut"
# echo "trafbyteOut: $trafbyteOut"

#----calculation-In----------------------#

if [ $trafbyteIn -gt $traflastIn ]; then
   trafdiffIn=$(echo " $trafbyteIn - $traflastIn " | bc)

elif [ $trafbyteIn -lt $traflastIn ]; then
   # this counter cannot be reset, unless the system was restarted
   # so no calculation here - we assume the current value IS the diff
   trafdiffIn=$trafbyteIn

fi

#----calculation-Out---------------------#

if [ $trafbyteOut -gt $traflastOut ]; then
   trafdiffOut=$(echo " $trafbyteOut - $traflastOut" | bc)

elif [ $trafbyteOut -lt $traflastOut ]; then
   # this counter cannot be reset, unless the system was restarted
   # so no calculation here - we assume the current value IS the diff
   trafdiffOut=$trafbyteOut

fi

#----human-readable-for-output-----------#

trafmbIn=`echo "scale=2; ( $trafbyteIn - $traflastIn ) * 8 / $sleep / 1024 / 1024 " | bc`
trafmbOut=`echo "scale=2; ( $trafbyteOut - $traflastOut ) * 8 / $sleep / 1024 / 1024 " | bc`
trafmb=`echo "scale=2; $trafmbIn + $trafmbOut" | bc`
trafmb1=`echo "$trafmb / 1" | bc`


# echo "trafmbIn: $trafmbIn"
# echo "trafmbOut: $trafmbOut"
# echo "trafmb: $trafmb"
# echo "trafmb1: $trafmb1"
#

#----write-values-for-next-run-----------#

# if any variable is 0 or has no value at all better do nothing and quit unknown
for X in "$trafbyteIn" "$trafbyteOut"
do
   if [ -z $X ]; then
        echo "Traffic UNKNOWN - $trafmb Mb/s in Sum|traffic=$trafmb;$warn;$crit;0; In=$trafmbIn;;;0; Out=$trafmbOut;;;0;"
        exit 3
   fi
   if [ $X = 0 ]; then
        echo "Traffic UNKNOWN - $trafmb Mb/s in Sum|traffic=$trafmb;$warn;$crit;0; In=$trafmbIn;;;0; Out=$trafmbOut;;;0;"
        exit 3
   fi
done

# echo $trafbyteIn $trafsumIn $trafbyteOut $trafsumOut > $tmpfile

#----output-and-exit-code----------------#

exprwarn=` echo $trafmb1 $warn | bc `
exprcrit=` echo $trafmb1 $crit | bc `

if [ $exprcrit -eq 1 ]; then
   echo "Traffic CRITICAL - $trafmb Mb/s in Sum|traffic=$trafmb;$warn;$crit;0; In=$trafmbIn;;;0; Out=$trafmbOut;;;0;"
   EXIT=2
elif [ $exprwarn -eq 1 ]; then
   echo "Traffic WARNING - $trafmb Mb/s in Sum|traffic=$trafmb;$warn;$crit;0; In=$trafmbIn;;;0; Out=$trafmbOut;;;0;"
   EXIT=1
elif [ $exprwarn -eq 0 -a $exprcrit -eq 0 ]; then
   echo "Traffic OK - $trafmb Mb/s in Sum|traffic=$trafmb;$warn;$crit;0; In=$trafmbIn;;;0; Out=$trafmbOut;;;0;"
   EXIT=0
else
   echo "Traffic UNKNOWN - $trafmb Mb/s in Sum|traffic=$trafmb;$warn;$crit;0; In=$trafmbIn;;;0; Out=$trafmbOut;;;0;"
   EXIT=3
fi

exit $EXIT

