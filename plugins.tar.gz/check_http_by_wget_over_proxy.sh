#!/bin/bash

NAME=$(basename $0)

show_help () {
  cat <<EOT
  usage: $NAME [ -h|--help ]
               [ -v|--verbose ]
                 -p|--proxy <proxyurl>
                 -u|--url <url>
               [ -e|--expect <http code> ]
               [ --no-check-certificate ]

  example:
         $NAME --proxy http://proxy:3128 --url https://testsite.com
EOT
  exit 3
}

WGET_OPTIONS=""
VERBOSE=0
EXPECT=200
while [ $# -gt 0 ]; do
  case $1 in
    -h|--help)
      show_help;
      shift
    ;;
    -p|--proxy)
      PROXY=$2;
      shift 2
    ;;
    -u|--url)
      URL=$2;
      shift 2
    ;;
    -e|--expect)
      EXPECT=$2;
      shift 2
    ;;
    -v|--verbose)
      VERBOSE=1
      shift
    ;;
   --no-check-certificate) 
      WGET_OPTIONS="$WGET_OPTIONS --no-check-certificate"
      shift
    ;;
    *)
      echo "$NAME UNKNOWN - unknown parameter $1"
      exit 3
    ;;
  esac
done
if [ -z $URL ]; then
  echo "$NAME UNKNOWN - url parameter missing"
  exit 3
fi
if [ -z $PROXY ]; then
  echo "$NAME UNKNOWN - proxy parameter missing"
  exit 3
fi
if [ $VERBOSE -eq 0 -a $EXPECT -eq 200 ]; then
  WGET_OPTIONS="$WGET_OPTIONS -nv"
fi

[ $VERBOSE -gt 0 ] && set -x
output=$(https_proxy=$PROXY http_proxy=$PROXY wget -O - -S --tries=1 --timeout=20 $WGET_OPTIONS $URL 2>&1)
RC=$?
[ $VERBOSE -gt 0 ] && set +x

if [ $EXPECT -ne 200 ]; then
  STATUS=$(echo "$output" | grep -P '^\s+HTTP' | awk '{ print $2 }')
  if [ $EXPECT -eq $STATUS ]; then
    echo "$NAME OK - got expected response code: $STATUS"
    exit 0
  fi
fi

if [ $RC -eq 0 ]; then
  echo "$NAME OK - got valid page"
  exit 0
fi
echo -n "$NAME CRITICAL - "
echo "$output" | grep -v WARNING: | grep -v "Unable to locally verify"
exit 2
