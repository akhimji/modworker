#!/bin/bash
#  
# Nagios check script for vmware vmfs
#  last modified by Jake Paulus 20080704
#
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# please add the following to your ESX server in the /etc/snmp/snmpd.conf and restart the snmpd deamon
#  exec .1.3.6.1.4.1.6876.99999.1 vdf /usr/sbin/vdf -h
# 
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#
# Call this command as follows:
# check_snmp_vmfs.sh [devicename] [snmp read community] [mount point] [warn] [crit] 
#
#	[warn] should be larger than [crit]
#	you may only check one mount point at a time until I (or someone else) make this script fancier
#	This script checks for free space in GB. If free space is measured in MB, it figures you're already
#	in trouble.

print_usage() {
        echo ""
        echo "Please open this file in a text editor to read the documentation in the comments at the top."
	echo ""
        echo "Usage: $0 [devicename] [snmp read community] [mount point] [warn] [crit]"
        echo "where [warn] and [crit] are integer values of number of gigabytes free"
	echo ""
        exit 3
}


case "$1" in
        --help)
                print_usage
                ;;
        -h)
                print_usage
                ;;
esac

if [ "$#" -ne "5" ]; then
	print_usage
fi

device=$1
community=$2
mount=$3
warn=$4
crit=$5

# execute the command on vdf command on the esx server
available=`snmpwalk -v 2c -c $community $device .1.3.6.1.4.1.6876.99999.1.101 | grep % | grep -i $mount`

test=`echo "$available" | egrep -c '[\n]'`
if [ $test -gt 1 ] ; then
	echo "More than one result was found. Please make your \"mount\" keyword more specific."
	exit 3
fi

if [ $test -lt 1 ] ; then
        echo "No data returned from host. Please check your configuration."
        exit 3
fi

available=`echo "$available" | awk '{ print $7 }'`
numericAvailable=`echo "$available" | sed s/[a-zA-Z]*//g`

echo "$available" | grep M
if [ $? -eq 0 ] ; then # free space is measured in megabytes - danger Will Robinson!
	echo "CRITICAL: no free space!"
	exit 2
fi

echo "$available" | grep T
if [ $? -eq 0 ] ; then # free space is measured in terabytes
	numericAvailable=`echo $numericAvailable * 1000 | bc`
else # space is in GB already - need to make sure it is an integer, not a floating point number - we'll round to the nearest decimal
	numericAvailable=`printf "%.0f\n" $numericAvailable`
fi

if [ $numericAvailable -gt $warn ] ; then 
	echo "OK - $numericAvailable gigabytes free"
	exit 0
fi

if [ $numericAvailable -gt $crit ] ; then
	echo "WARNING - $numericAvailable gigabytes free"
	exit 1
else 
	echo "CRITICAL - $numericAvailable gigabytes free"
	exit 2
fi
