#!/bin/bash
# Wrapper script for check_mbean_collector.pl to parse performance data for complex attributes.
# Author: Ryan Shows 2015-12-14

HOST=$1
PORT=$2
MBEAN=$3
ATTRIBUTE=$4
WARNING=$5
CRITICAL=$6

usage() {
 echo "Usage: check_mbean_collector.sh <HOST> <PORT> <MBEAN> <ATTRIBUTE> <WARNING> <CRITICAL>"
}

if [ "$#" -lt 6 -o "$#" -gt 6 ]; then
	usage
	exit 1
fi



RESULT=`/usr/lib64/nagios/plugins/check_mbean_collector.pl -H $HOST -p $PORT -m "$MBEAN" -a $ATTRIBUTE -w $WARNING -c $CRITICAL` 
PERF_DATA=`echo "$RESULT" | sed 's/^.*={//' | sed 's/, /;/g' | sed 's/})//'`

echo "${RESULT} | $PERF_DATA"

exit 0
