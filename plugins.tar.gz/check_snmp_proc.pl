#!/usr/bin/perl
# nagios: +epn
#
# (P) & (C) 2008-2010 Venyon <operations@venyon.com>
#
# Authors:      Dr. Peter Bieringer (bie)
#               Sven Nierlein (nie)
#
# Changes:
# 2008xxxx/nie: initial
# 20090916/bie: improved implementation using perl SNMP function
# 20090916/bie: do not lowercase process names
# 20091512/bie: implement negative process checker
#               minor speedup by switch from array to hash check
# 20100601/bie: implement support for argument checks (e.g. useful for java processes) hrSWRunParameters
# 20100602/bie: implement support for argument checks (e.g. useful for oracle processes) hrSWRunPath
# 20100714/bie: remove PROGNAME from output
# 20131011/bie: add SNMPv3 support


=head1 NAME

nagios_check_snmp_proc.pl - checks running processes via snmp

=head1 SYNOPSIS

./nagios_check_snmp_proc.pl -H <ip_address> [-C community] [-P snmp version] [-t timeout] [-h] [-v] [-V] processname1 processname2...  ^should-not-exist-processname3 processname4:hrSWRunParameters processname4=hrSWRunPath
                                      [-u <SNMPv3 user>]
                                      [-a <SNMPv3 auth proto>]
                                      [-A <SNMPv3 auth pass>]
                                      [-x <SNMPv3 priv proto>]
                                      [-X <SNMPv3 priv pass>]
                                      [-l <SNMPv3 security level>]

=head1 OPTIONS

=over 5

=item processnames

    List of processnames which must be running

=item -h

    Print detailed help screen

=item -V

    Print version information

=item -H

    Host name or IP Address

=item -P [1|2c]

    SNMP protocol version

=item -C

    Optional community string for SNMP communication (default is "public")

=item -t

    Seconds before connection times out (default: 10)

=item -v

    Show details for command-line debugging (Nagios may truncate output)

=back

=head1 DESCRIPTION

Checks for running processes via snmp.

This plugin uses the 'snmpwalk' command included with the NET-SNMP package.
if you don't have the package installed, you will need to download it from
http://net-snmp.sourceforge.net before you can use this plugin.

=cut

use warnings;
use strict;
use Getopt::Long;
use Pod::Usage;
use Data::Dumper;
use SNMP 5.0;
use vars qw ($snmp_session);
use lib '/usr/lib/nagios/plugins';
use lib '/usr/lib64/nagios/plugins';
use utils qw(%ERRORS &print_revision);

check();

sub check {
    my $PROGNAME = 'venyon_nagios_check_snmp_proc';
    my $VERSION  = '$Revision: 1 $';

    ################################################
    # set defaults
    my $timeout       = 30;
    my $snmpcommunity = "public";
    my $snmpversion   = "2c";

    ################################################
    # parse command line arguments
    my ($opt_H,$opt_h,$opt_v,$opt_t,$opt_V,$opt_C,$opt_P,@procs, $opt_a, $opt_A, $opt_x, $opt_X, $opt_l, $opt_u);
    Getopt::Long::Configure("no_ignore_case");
    GetOptions(
       "H=s"        => \$opt_H,
       "v"          => \$opt_v,
       "h"          => \$opt_h,
       "t=i"        => \$opt_t,
       "V"          => \$opt_V,
       "C=s"        => \$opt_C,
       "P=s"        => \$opt_P,
       "a=s"        => \$opt_a,
       "A=s"        => \$opt_A,
       "x=s"        => \$opt_x,
       "X=s"        => \$opt_X,
       "l=s"        => \$opt_l,
       "u=s"        => \$opt_u,
       "<>"         => sub { push @procs, @_ },
    );

    my($opt_procs, $opt_procs_exist, $opt_procs_nonexist) = getProcs(\@procs);

    ########################################################
    if ($opt_V) {
      print_revision($PROGNAME, $VERSION);
      exit $ERRORS{'OK'};
    }

    ########################################################
    # set a timeout
    if(defined $opt_t) { $timeout = $opt_t; }
    $SIG{ALRM} = sub{
      print "CRITICAL: timeout after $timeout seconds.";
      exit $ERRORS{"CRITICAL"}; 
    };
    alarm($timeout);

    ################################################
    # just print the help message?
    if(defined $opt_h) {
      pod2usage( { -verbose => 1 } );
      exit $ERRORS{'OK'};
    }

    ################################################
    # should we be verbose?
    my $verbose  = 0;
    if(defined $opt_v) {
      $verbose   = 1;
    }

    ################################################
    # check for a valid hostname
    if(!defined $opt_H) {
      pod2usage( { -verbose => 1, -msg => "Error: -H <hostname> is a required option." } );
      exit $ERRORS{"UNKNOWN"}; 
    }

    ################################################
    # check for a valid processes
    if(scalar keys %{$opt_procs} <= 0) {
      pod2usage( { -verbose => 1, -msg => "Error: please specify at least on process" } );
      exit $ERRORS{"UNKNOWN"}; 
    }

    ################################################
    # set snmp community
    if(defined $opt_C) {
      $snmpcommunity = $opt_C;
    }

    ################################################
    # set snmp protocol version
    if(defined $opt_P) {
      $snmpversion = $opt_P;
    }

    # create a session for conversing with the remote SNMP agent
    $snmp_session = new SNMP::Session(
        DestHost => $opt_H,
        Community => $opt_C,
        Version   => $snmpversion,
        SecLevel  => $opt_l,
        AuthProto => $opt_a,
        AuthPass  => $opt_A,
        PrivProto => $opt_x,
        PrivPass  => $opt_X,
        SecName   => $opt_u
    );

    if(!$snmp_session) {
      print "UNKNOWN - snmp connect failed\n";
      exit $ERRORS{"UNKNOWN"}; 
    }

    my @snmpwalkout;
    my %foundProcs;
    my %Procs;

    my $rc = snmpwalk(\%Procs, [ "hrSWRunName" ], $opt_procs, $verbose);

    if($rc != 0) {
      print "UNKNOWN - snmpwalk failed with rc $rc: ".join(" ", @snmpwalkout)."\n";
      exit $ERRORS{"UNKNOWN"}; 
    }

    for my $entry (keys %Procs) {
        #logger("List entry: " . $entry);
        my $proc = $Procs{$entry};
        $foundProcs{$proc}++;
    };
    print STDERR "found:"             if $verbose;
    print STDERR Dumper(\%foundProcs) if $verbose;


    ################################################
    # now that we have a list of running procs, check if there are any which is missing
    my %missedSome;
    my %perfProcs;
    for my $searchProc (sort @{$opt_procs_exist}) {
	#logger("Search for process: " . $searchProc);
	my ($proc,$arg);
	if ($searchProc =~ /[:=]/) {
		# search in process arguments
		($proc,$arg) = split(/[:\=]/, $searchProc);
		#logger("Reduce search process to: " . $proc);
	} else {
		$proc = $searchProc;
	};

	#logger("Search for process: " . $proc);

	#logger("List: " . $proc);

	if (! defined $foundProcs{$proc}) {
		#logger("Process missing: " . $proc);
		$missedSome{$searchProc} = 1;
		$perfProcs{$searchProc} = 0;
	} elsif (defined $arg) {
		#logger("Search for process argument: " . $arg);

		# search through processes
		my $found = 0;
		for my $entry (keys %Procs) {
			if ($Procs{$entry} eq $proc) {
				# extract PID
				$entry =~ /^hrSWRunName.([0-9]+)$/;
				my $pid = $1;
				#logger("PID entry: " . $pid);

				my $argcheck;
				if ($searchProc =~ /:/o) {
					$argcheck = snmpget( [ "HOST-RESOURCES-MIB::hrSWRunParameters." . $pid ] );
					#logger("hrSWRunParameters: " . $argcheck);
				} elsif ($searchProc =~ /=/o) {
					$argcheck = snmpget( [ "HOST-RESOURCES-MIB::hrSWRunPath." . $pid ] );
					#logger("hrSWRunPath: " . $argcheck);
				};


				if ($argcheck =~ /$arg/) {
					$found++;
				};
			};
		};

		if ($found == 0){
			$missedSome{$searchProc} = 1;
			$perfProcs{$searchProc} = 0;
		} else {
			$perfProcs{$searchProc} = $found;
		};
	} else {
		#logger("nothing more todo");
		$perfProcs{$searchProc} = $foundProcs{$searchProc};
	};
    };

    # check for processes, which should not run
    my %existSome;
    for my $searchProc (sort @{$opt_procs_nonexist}) {
      if(defined $foundProcs{$searchProc}) {
        $existSome{$searchProc} = 1;
        $perfProcs{$searchProc} = 0;
        $perfProcs{$searchProc} = $foundProcs{$searchProc};
      }
    }

    ################################################
    # do the performance data
    my @perfData;
    for my $procName (sort keys %perfProcs) {
      push @perfData, $procName."=".$perfProcs{$procName};
    }
    my $perfString = "|".join(" ", @perfData);

    if(scalar keys %missedSome > 0) {
      print "CRITICAL - missing processes: ".join(", ", sort keys %missedSome).$perfString."\n";
      exit $ERRORS{"CRITICAL"}; 
    }

    if(scalar keys %existSome > 0) {
      print "WARNING - unexpected processes exist: ".join(", ", sort keys %existSome).$perfString."\n";
      exit $ERRORS{"WARNING"}; 
    }


    print "OK - all processes are running".$perfString."\n";
    exit $ERRORS{"OK"}; 
}

################################################
# SUBS
################################################

################################################
# getProcs - callback for parameterparsing
sub getProcs {
    my $procs = shift;
    my(%opt_procs, @opt_procs_exist, @opt_procs_nonexist);
    for my $procName (@{$procs}) {
        # do nothing
        next if $procName =~ m/^\s*$/mxo;

        if (substr($procName,0,1) eq "^") {
            $procName =  substr($procName,1);
            push @opt_procs_nonexist, $procName;
        } else {
            push @opt_procs_exist, $procName;
        }

        if ($procName =~ /[:=]/) {
            my ($proc,$arg) = split(/[:=]/, $procName);
            $opt_procs{$proc} = 1;
        } else {
            $opt_procs{$procName} = 1;
        }
    }
    return(\%opt_procs, \@opt_procs_exist, \@opt_procs_nonexist);
}

################################################
# strip - strip off whitespace and quotes
sub strip {
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  $string =~ s/^"//;
  $string =~ s/"$//;
  return($string);
}

sub check_for_errors {
    if ( $snmp_session->{ErrorNum} ) {
        print "UNKNOWN - error retrieving SNMP data: $snmp_session->{ErrorStr}\n";
        exit $ERRORS{UNKNOWN};
    }
}

#sub logger($) {
#        if ($debug > 0) {
#            print STDERR $_[0] . "\n";
#        };
#}

# snmpwalk
sub snmpwalk {
    my($phash,$oid,$pcheck,$verbose) = @_;
    my $tmpvar = SNMP::Varbind->new($oid);
    my $oid_check = @$oid[0];
    my $pcheck_check = 0;

    # check 
    if (scalar keys %{$pcheck} > 0) {
#	if ($verbose == 1) {
#		print "DEBUG : enable to pcheck check\n";
#	}
	$pcheck_check = 1;
    };

    my $flag = 0;
    do {
	my $val = $snmp_session->getnext($tmpvar);

	check_for_errors();
	#logger("OID Check  : " . $oid_check);
	#logger("OID Current: " . $oid_current);
        if ( (${$tmpvar}[0] . "." . ${$tmpvar}[1]) !~ /^$oid_check/) {
		#logger("Not matching");
	    $flag = 1;
	} else {
	    print "@{$tmpvar}\n" if $verbose;
		if ($pcheck_check == 1) {
			if (defined ${$pcheck}{${$tmpvar}[2]}) {
				${$phash}{${$tmpvar}[0] . "." . ${$tmpvar}[1]} = ${$tmpvar}[2];
			};
		} else {
			${$phash}{${$tmpvar}[0] . "." . ${$tmpvar}[1]} = ${$tmpvar}[2];
		};
	};

    } until ($snmp_session->{ErrorNum} || $flag == 1);

    return 0;
}

# get SNMP entry

sub snmpget {
    my $tmpvar = SNMP::Varbind->new( shift );
    $snmp_session->get( $tmpvar );
    check_for_errors();
    return $tmpvar->val;
}


################################################


